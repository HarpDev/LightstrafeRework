﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Always_Render")]
public class BakeryAlwaysRender : MonoBehaviour {
}
