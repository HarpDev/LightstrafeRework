﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[HelpURL("https://geom.io/bakery/wiki/index.php?title=Manual#Bakery_Shared_LOD_UV")]
public class BakerySharedLodUv : MonoBehaviour{
}
