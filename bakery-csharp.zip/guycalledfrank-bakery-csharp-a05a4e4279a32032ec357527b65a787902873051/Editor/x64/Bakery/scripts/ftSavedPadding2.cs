using UnityEngine;
using UnityEditor;

public class ftSavedPadding2 : ScriptableObject
{
    [SerializeField]
    public ftGlobalStorage.AdjustedMesh data;
}
