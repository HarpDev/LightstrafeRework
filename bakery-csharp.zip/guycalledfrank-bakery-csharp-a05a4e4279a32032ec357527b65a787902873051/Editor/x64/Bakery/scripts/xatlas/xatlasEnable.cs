using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;

public partial class ftModelPostProcessor : ftModelPostProcessorInternal
{
    public override void UnwrapXatlas(Mesh m, UnwrapParam param)
    {
        xatlas.Unwrap(m, uparams);
    }
}

